package com.example.flappy_dracula

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
